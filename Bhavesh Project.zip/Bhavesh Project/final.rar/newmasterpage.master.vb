﻿
Partial Class newmasterpage
    Inherits System.Web.UI.MasterPage
End Class

