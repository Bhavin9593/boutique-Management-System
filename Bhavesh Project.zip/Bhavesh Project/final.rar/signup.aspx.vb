﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class signup
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand
    Public Sub clear()
        fnt.Text = ""
        lnt.Text = ""
        addr.Text = ""
        email.Text = ""
        pwd.Text = ""
        phn.Text = ""
        rpwd.Text = ""

    End Sub
    Protected Sub rb_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb.Click
        Call clear()
    End Sub

    Protected Sub sb_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles sb.Click
        Dim q As String = "insert into cust_mst values('" + fnt.Text + "','" + lnt.Text + "','" + addr.Text + "','" + phn.Text + "','" + email.Text + "','" + pwd.Text + "')"

        cmd = New SqlCommand(q, cn)
        Dim a As Integer
        a = cmd.ExecuteNonQuery()

        If a > 0 Then
            MsgBox("Sucessfully Registered")
            Response.Redirect("login.aspx")

        End If

        ''Call clear()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Bhavin\Documents\Visual Studio 2010\WebSites\final\App_Data\tailor.mdf;Integrated Security=True;User Instance=True")
        cn.Open()
    End Sub
End Class
