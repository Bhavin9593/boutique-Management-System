﻿
Partial Class adminmaster
    Inherits System.Web.UI.MasterPage
End Class

