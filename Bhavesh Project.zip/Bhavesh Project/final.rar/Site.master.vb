﻿
Partial Class Site
    Inherits System.Web.UI.MasterPage
End Class

