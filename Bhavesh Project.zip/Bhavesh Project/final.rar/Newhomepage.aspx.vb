﻿
Partial Class Newhomepage
    Inherits System.Web.UI.Page

End Class
