﻿
Partial Class price
    Inherits System.Web.UI.Page

End Class
