﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class login
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader

    Protected Sub sb_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles sb.Click
        If email.Text = "" Then
            MsgBox("Enter Email ID")
        End If
        If pwd.Text = "" Then
            MsgBox("Enter Password")
        End If
        If email.Text = "rathod25@gmail.com" And pwd.Text = "2512" Then


            Session("email") = "Admin"
            MsgBox("Admin Login Sucessfully")
            Response.Redirect("adminhome.aspx")

        Else
            cmd = New SqlCommand("select * from cust_mst where email='" + email.Text + "' and pwd='" + pwd.Text + "'", cn)
            dr = cmd.ExecuteReader()
            If dr.Read() = True Then

                Session("email") = dr.Item("fname").ToString
                MsgBox("Login Sucessfully")
                Response.Redirect("home.aspx")
            Else
                MsgBox("Email or password incorrect")
            End If
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Bhavin\Documents\Visual Studio 2010\WebSites\final\App_Data\tailor.mdf;Integrated Security=True;User Instance=True")
        cn.Open()
        Show.Visible = False
    End Sub


    Protected Sub Show_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Show.Click
        pwd.TextMode = TextBoxMode.SingleLine
        Show.Visible = False
    End Sub

    Protected Sub rb_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb.Click
        email.Text = ""
        pwd.Text = ""
    End Sub

    Protected Sub pwd_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles pwd.Load
        Show.Visible = True
    End Sub
End Class
