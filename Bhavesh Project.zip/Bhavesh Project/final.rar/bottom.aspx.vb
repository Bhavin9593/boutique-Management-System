﻿Imports System.Data
Imports System.Data.SqlClient


Partial Class bottom
    Inherits System.Web.UI.Page

    Dim con As SqlConnection
    Dim cmd As SqlCommand
    Dim ssn As String
    Dim cat As String


    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim price As Integer

        If DropDownList1.SelectedValue = "cotton" Then
            price = "300"
        ElseIf DropDownList1.SelectedValue = "rion" Then
            price = "400"
        ElseIf DropDownList1.SelectedValue = "terry cotton" Then
            price = "300"
       
        Else
            price = "450"

        End If

        Dim total, teridhyadi As Integer
        teridhyadi = "300"
        total = teridhyadi + price

        cat = "bottom"
        ssn = "username"
        Dim fabric As String = DropDownList1.SelectedValue
        Dim bstyle As String = DropDownList2.SelectedValue
        Dim payment As String
        If RadioButton1.Checked = True Then
            payment = "cash on delivery"
        End If
        If RadioButton2.Checked = True Then
            payment = "pay in the shop"
        End If

        Dim q As String

        q = "insert into shivambottombill values('" + cat.ToString + "','" + fabric.ToString + "','" + TextBox1.Text.ToString + "','" + bstyle.ToString + "','" + TextBox2.Text.ToString + "','" + TextBox3.Text.ToString + "','" + ssn.ToString + "','" + payment.ToString + "','" + total.ToString + "')"
        MsgBox(q)

        cmd = New SqlCommand(q, con)
        Dim a As Integer

        a = cmd.ExecuteNonQuery()
        If a > 0 Then
            MsgBox("order successful")
        Else
            MsgBox("awwwww!!")
        End If

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        con = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Bhavin\Documents\Visual Studio 2010\WebSites\final\App_Data\tailor.mdf;Integrated Security=True;User Instance=True")
        con.Open()
    End Sub
End Class
