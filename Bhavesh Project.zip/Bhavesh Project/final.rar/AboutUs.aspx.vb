﻿
Partial Class AboutUs
    Inherits System.Web.UI.Page

End Class
