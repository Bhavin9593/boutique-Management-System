﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class blousepage
    Inherits System.Web.UI.Page

    Dim con As SqlConnection
    Dim cmd As SqlCommand
    Dim ssn As String
    Dim cat As String
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim price As Integer

        If DropDownList1.SelectedValue = "georgette" Then
            price = "400"
        ElseIf DropDownList1.SelectedValue = "satin" Then
            price = "390"
        ElseIf DropDownList1.SelectedValue = "cotton" Then
            price = "300"
        ElseIf DropDownList1.SelectedValue = "velvet" Then
            price = "500"
        Else
            price = "350"

        End If

        Dim total, teridhyadi As Integer
        teridhyadi = "500"
        total = teridhyadi + price



        cat = "blouse"
        ssn = "username"
        Dim fabric As String = DropDownList1.SelectedValue
        Dim fneck As String = DropDownList3.SelectedValue
        Dim bneck As String = DropDownList4.SelectedValue
        Dim sleeve As String = DropDownList5.SelectedValue
        Dim payment As String
        If RadioButton1.Checked = True Then
            payment = "cash on delivery"
        End If
        If RadioButton2.Checked = True Then
            payment = "pay in the shop"
        End If
        Dim q As String

        q = "insert into shivambill values('" + cat.ToString + "','" + fabric.ToString + "','" + TextBox2.Text.ToString + "','" + fneck.ToString + "','" + bneck.ToString + "','" + sleeve.ToString + "','" + TextBox1.Text.ToString + "','" + TextBox3.Text.ToString + "','" + ssn.ToString + "','" + payment.ToString + "','" + total.ToString + "')"

        cmd = New SqlCommand(q, con)
        Dim a As Integer
        MsgBox(q)
        a = cmd.ExecuteNonQuery()
        If a > 0 Then
            MsgBox("order successful")
        Else
            MsgBox("awwwww!!")
        End If

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        con = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Bhavin\Documents\Visual Studio 2010\WebSites\final\App_Data\tailor.mdf;Integrated Security=True;User Instance=True")
        con.Open()
    End Sub
End Class
